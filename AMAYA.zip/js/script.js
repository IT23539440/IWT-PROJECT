<script>
<script>
    // Function to validate the form before submission
    function validateForm(event) {
        event.preventDefault(); // Prevent the form from submitting

        // Get form values
        const name = document.querySelector('input[name="sname"]').value;
        const email = document.querySelector('input[name="semail"]').value;
        const contact = document.querySelector('input[name="scontact"]').value;
        const message = document.querySelector('input[name="smassage"]').value;

        // Basic validation
        if (!name || !email || !contact || !message) {
            alert('Please fill in all fields.');
            return false;
        }

        // Regex for email validation
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            alert('Please enter a valid email address.');
            return false;
        }

        // If everything is valid, submit the form
        document.querySelector('form').submit();
    }

    // Attach event listener to the form
    document.addEventListener('DOMContentLoaded', () => {
        const form = document.querySelector('form');
        form.addEventListener('submit', validateForm);
        
        // Add click event to the cancel button
        const cancelButton = document.querySelector('.buttons .app-form-button[type="button"]');
        cancelButton.addEventListener('click', () => {
            form.reset(); // Reset the form fields
        });
    });


</script>