<html>
<head>
</head>
<body>
    <from method="post" action="update.php">
        name: <input type="text" name="sname"><br>
        email:<input type="text" name="semail"><br>
        contact:<input type="text" name="scontact"><br>
        massage:<input type="text" name="smessage"><br>
        <input type="submit" value="update">

</body>
</html>
