<!DOCTYPE html>
<html>
<head>
 <title>Package</title>
 <meta charset="utf-8">
 <meta name="viewport" contenwidth="device-width, initial-scale=1.0">
 <link rel="stylesheet" href="../css/style.css">
 
</head>
<body>
<div class="card-container"> 
    <div class="card">
        <img src="C:\xampp NEWW\htdocs\Tharushi\image/86.jpg">
        <div class="card-content">
            <h3>Madu River</h3>
            <p>Creating Responsive CSS Cards | Card Design HTM & CSS
            In this video, we explore the process of designing and coding
            responsive CSS cards that will elevate your web design skills.</p>
            <ul>
                <li><i class="fa fa-star checked"></i></li> 
                <li><i class="fa fa-star checked"></i></li> 
                <li><i class="fa fa-star checked"></i></li> 
                <li><i class="fa fa-star checked"></i></li> 
                <li><i class="fa fa-star"></i></li> 
            </ul>
            <a href="" class="btn">Read More</a>
        </div>
    </div>

    <div class="card">
        <img src="C:\xampp NEWW\htdocs\Tharushi\image/pic01.jpeg">
        <div class="card-content">
            <h3>Pasikuda Beach</h3>
            <p>Creating Responsive CSS Cards | Card Design HTM & CSS
            In this video, we explore the process of designing and coding
            responsive CSS cards that will elevate your web design skills.</p>
            <ul>
                <li><i class="fa fa-star checked"></i></li> 
                <li><i class="fa fa-star checked"></i></li> 
                <li><i class="fa fa-star checked"></i></li> 
                <li><i class="fa fa-star checked"></i></li> 
                <li><i class="fa fa-star"></i></li> 
            </ul>
            <a href="" class="btn">Read More</a>
        </div>
    </div>

    <div class="card">
        <img src="C:\xampp NEWW\htdocs\Tharushi\image/pic02.jpeg">
        <div class="card-content">
            <h3>Mahaweli River</h3>
            <p>Creating Responsive CSS Cards | Card Design HTM & CSS
            In this video, we explore the process of designing and coding
            responsive CSS cards that will elevate your web design skills.</p>
            <ul>
                <li><i class="fa fa-star checked"></i></li> 
                <li><i class="fa fa-star checked"></i></li> 
                <li><i class="fa fa-star checked"></i></li> 
                <li><i class="fa fa-star checked"></i></li> 
                <li><i class="fa fa-star"></i></li> 
            </ul>
            <a href="" class="btn">Read More</a>
        </div>
    </div>


</div>
</body>
</html>